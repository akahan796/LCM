# LCM Prototype — build-less React

The Lifecycle Management (LCM) UX prototype, as a self-contained **build-less React** app.

- `index.html` — the whole app (React 18 + `htm` loaded from a CDN; no build step, no `npm install`).
- `logo.png`, `fonts/` — brand assets (OneStream Sans).

## Run it
Just open `index.html` in a browser, **or** serve the folder statically:

```
python3 -m http.server 8000
# then visit http://localhost:8000
```

(A static server is recommended so the fonts and module imports load cleanly.)

## Notes
- React and `htm` are imported from `esm.sh` at runtime — an internet connection is required on first load.
- Components: `App`, `Sidebar`, `TopBar`, `ActivityView` (search, sort, filter builder), `TemplatesView`.
- The app includes a tiny `postMessage` hook so it can be embedded in a preview frame; standalone it's inert.
