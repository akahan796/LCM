# ODS Filter Builder — standalone

A self-contained extract of the LCM filter builder (build-less React), running against a small sample dataset so you can see and use it in isolation.

- `index.html` — the filter demo (React 18 + `htm` from a CDN; no build step).
- `fonts/` — OneStream Sans.

## Run it
Open `index.html`, or serve the folder statically:

```
python3 -m http.server 8000
# http://localhost:8000
```

## What it demonstrates
- **AND / OR connectors** between conditions (independently editable).
- **Field locks** once selected; **Value is multi-select** (checkboxes; any-of match).
- Operators: Contains / Does not contain / Equals.
- **Live filtering** — the grid updates as you build; a count badge shows active filters.
- Add / remove conditions, **Clear All**, fixed-height scroll past 3 conditions, and a 1s idle auto-close.

## Reusing it
The relevant pieces to lift into your own app: the `Dropdown` component, `matchConditions()`, the filter-panel markup/handlers inside `FilterDemo`, and the `/* Filter panel */` + `.dd*` CSS blocks.
